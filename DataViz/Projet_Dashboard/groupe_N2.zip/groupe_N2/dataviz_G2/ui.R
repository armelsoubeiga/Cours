


# Define UI for application that draws a histogram
shinyUI( dashboardPage (
  dashboardHeader(titleWidth = 0 ),
  
  dashboardSidebar(width = 160,
                   tags$hr(),
                   tags$img(src = "logo.png", width = "100%", 
                            style='text-align:center; height:170px; border:2px;
                              border-style:solid;border-color:black'), 
                   tags$hr(),
                   selectInput(inputId="categorical_variable", label = "Selectionner une variable qualitative :", choices = categorical_variable, selected = categorical_variable[1]),
                   
                   selectInput(inputId="numeric_variable", label = "Selectionner une variable numérique :", choices = numeric_variable, selected = numeric_variable[1])
                   
  ),
  
  dashboardBody(theme,
                tags$hr(style='border:1px; border-style:solid;border-color:black'),
                tags$h1(HTML("<marquee behavior='alternate' scrollamount=1 height=60 
                               style='font-family:times; color:blue; font-size:38pt;
                               font-style:bold'> 
                               Visualisation des attaques terroristes au BURKINA FASO 
                               </marquee>")),
                tags$hr(style='border:1px; border-style:solid;border-color:black'),
                
                tabsetPanel(
                  tabPanel(div("Cartographie des attaques terroristes",
                               style='font-family:times; font-size:20pt; font-style:bold'),
                           tags$br(),
                           plotlyOutput("carte")
                           
                  ),
                  
                  tabPanel(div("Analyses Descriptives (1)",
                               style='font-family:times; font-size:20pt; font-style:bold'),
                           
                           plotlyOutput("plt")
                           
                  ),
                  
                  tabPanel(div("Analyses Descriptives (2)",
                               style='font-family:times; font-size:20pt; font-style:bold'),
                           
                           
                           # La mise en page multirow
                           fluidRow(
                             column(12, plotlyOutput("bar")),
                             tags$br(" ²"),  
                             fluidRow(
                               
                               column(12, plotlyOutput("b"))
                               #plotlyOutput("bar")
                             )
                             
                             
                             
                           )),
                  tabPanel(div("Analyses Descriptives (3)",
                               style='font-family:times; font-size:20pt; font-style:bold'),
                           
                           
                           fluidRow(column(12, plotlyOutput("interac1"))),
                           #column(8, plotlyOutput("interac2"))),
                           
                           fluidRow(column(12, plotlyOutput("interac3")))
                           
                  ),
                  
                  
                )),
  
  footer = dashboardFooter(
    
    left =HTML("<marquee behavior='alternate' scrollamount=2, scrolldelay=10, width='100%'> 
            <img src ='aa.jpg', style= 'width:100px; height:70px; border:3px; border-style:solid; border-color:blue'>
            <img src ='bb.jpg', style= 'width:100px; height:70px; border:3px; border-style:solid; border-color:blue'>
            <img src ='cc.jpg', style= 'width:100px; height:70px; border:3px; border-style:solid; border-color:blue'>
            <img src ='dd.jpg', style= 'width:100px; height:70px; border:3px; border-style:solid; border-color:blue'>
            <img src ='ee.jpg', style= 'width:100px; height:70px; border:3px; border-style:solid; border-color:blue'>
               </marquee>"))
)
)
