library(maps)
library(rsconnect)

# Define server logic required to draw a histogram
shinyServer(function(input, output, session) {
  
  # carte
  output$carte<- renderPlotly({ plot_geo(data,lon = ~data$longitude, lat = ~data$latitude, 
                                         # texte au passage de la souris
                                         text = ~paste(data$attacktypeun_txt,data$success, 
                                                       paste("La cible:", data$targtypeun_txt), sep = "<br />"),
                                         type = "scattergeo", split = ~data$provstate,
                                         mode = "markers", marker = list(size = 3)) %>%
      layout(geo = fond_carte, title = "Zone des attaques terroristes <br /> au BURKINA FASO")
  });
  
  
  
  output$plt <- renderPlotly({
    fig <- ggplot(data2, aes(x=iyear ,y= Effectifs ,color=attacktypeun_txt))+
      geom_line(size=0.5, alpha=0.75)+
      theme_solarized_2(light=F)+
      labs(title = "Type d'attaques par an","Type d'attaques")+
      theme(text=element_text(family = "dm", colour = "#EEEEEE"),
            title=element_text(color="#EEEEEE"),
            axis.title.x=element_blank(),
            panel.background = element_rect(fill = NA),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            legend.background = element_blank(),
            legend.key = element_blank(),
            legend.position = "bottom",
            plot.title = element_text(hjust=0.5))+
      scale_color_brewer(palette = "Pastel1")+
      transition_reveal(data2$iyear)+
      view_follow(fixed_y = T)
    ggplotly(fig)
  });
  
  ## courbe
  output$bar <- renderPlotly({
    #c<- ggplot(data, aes(data$provstate))+geom_bar()+coord_flip();ggplotly(c)
    dt <- data.frame(d1=data$provstate,d2=data$nkill)
    fig1 <- plot_ly(dt, labels = dt$d1, values = dt$d2, type = 'pie')
    fig1 <- fig1 %>% 
      layout(title = 'Nombre de decès en fonction des régions',
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    fig1});
  
  output$b <- renderPlotly({
    dtt <- data.frame(d3=data$targtypeun_txt,d4=data$nkill)
    fig2 <- plot_ly(dtt, labels = dtt$d3, values = dtt$d4, type = 'pie')
    fig2 <- fig2 %>%
      layout(title = 'Nombre de decès en fonction du type de cible',
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    fig2
    
    #ggplotly(c)
  });
  
  ##### Boxplot
  output$interac1 <- renderPlotly({
    plot_ly(data,
            x = ~data[[input$numeric_variable]],
            color = ~data[[input$categorical_variable]],
            colors = "Paired",
            type = "box") %>%
      layout(title = "",
             xaxis = list(title = "" ,
                          zeroline = FALSE))
  });
  
  
  
  ##### Histogramme
  output$interac3 <- renderPlotly({
    plot_ly(x = data[[input$categorical_variable]], 
            color = ~data[[input$categorical_variable]],
            type = "histogram", line = list(color = "Paired", width = 1))
  })
  
})
