
paquet = c("shiny", "shinydashboard",  "shinydashboardPlus","shinythemes",
             "shinyjs","dashboardthemes", "htmlwidgets" ,"DT" ,"gt" ,"pivottabler",
             "basictabler" ,"flextable", "dplyr","openxlsx","shinypivottabler",
             "shinyWidgets" , "tidyr", "highcharter" ,"echarts4r" ,"ECharts2Shiny",
             "labelled", "ggthemes", "gganimate", "plotly", "rnaturalearth")
  
library(rintrojs)

package.check <- lapply(paquet, FUN = function(x) {
  if (!require(x, character.only = TRUE)) {
    install.packages(x, dependencies = TRUE)
  }
})

source("theme.R")
# Importation des donn?es
data <- read.csv2("data/global.csv", sep=";")
str(data)

#data$iyear <- as.character (data$iyear)
getwd()

numeric_variable <- c("nkill", "nwound")

categorical_variable <- c("imonth",	"iday","critun",	"critdeux",	"crittrois",	"success",
                          "country_txt",	"region_txt",	"provstate",	"city","attacktypeun_txt",
                          "targtypeun_txt",	"corpun",	"targetun",	"natltyun_txt",	"corpdeux",
                          "targetdeux",	"natltydeux_txt",	"corptrois",	"targettrois","rnaturalearth",
                          "natltytrois_txt",	"gname")


data1 <- data %>%
  group_by(iyear) %>%
  transmute (nbdeces=sum(nkill , na.rm = TRUE), nbattaq=n()) %>%
  distinct()

data2 <- data %>%
  group_by(iyear,attacktypeun_txt) %>%
  transmute (Effectifs=n()) %>%
  drop_na()%>%
  distinct()


fond_carte <- list(
  scope = "africa",
  showland = TRUE,
  landcolor = toRGB("gray85"),
  subunitwidth = 1,
  countrywidth = 1,
  showland = TRUE,
  landcolor = toRGB("gray95"),
  subunitcolor = toRGB("white"),
  countrycolor = toRGB("white"))


